const express = require("express");
const nodemailer = require("nodemailer");
const bodyParser = require("body-parser");
const mysql = require("mysql");
const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Nodemailer setup
const transporter = nodemailer.createTransport({
  service: "gmail", // Use your email service
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// Create a MySQL connection
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log("MySQL connected");
});

// Register a new user and send a welcome email
app.post("/register", (req, res) => {
  const { username, email, password } = req.body;

  // Check if username or email already exists
  const checkUserSql = "SELECT * FROM users WHERE username = ? OR email = ?";
  db.query(checkUserSql, [username, email], (err, results) => {
    if (err) {
      return res.status(500).send({ message: "Database error" });
    }
    if (results.length > 0) {
      return res
        .status(409)
        .send({ message: "Username or email already exists" });
    }

    // If not, insert the new user
    const insertUserSql =
      "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    db.query(insertUserSql, [username, email, password], (err, result) => {
      if (err) {
        return res.status(500).send(err);
      }

      // Send welcome email
      const mailOptions = {
        from: "fahadlee2000727@gmail.com",
        to: email,
        subject: "Welcome to Our NASTAF",
        text: `Hi ${username},\n\nWelcome to our app! We're glad to have you on board.\n\nUsername: ${username}\nPassword: ${password}\n\nBest,\nThe Team`,
      };

      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.error('Error sending email:', error);
          return res.status(500).send({
            message: "User registered, but email failed to send.",
          });
        } else {
          console.log('Email sent successfully:', info.response);
          res.status(201).send({
            message: "User registered and email sent!",
          });
        }
      });
      

      console.log({ message: "User registered" });
      console.log({ username, email, password });
    });
  });
});

// Login a user
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const sql = "SELECT * FROM users WHERE username = ?";

  db.query(sql, [username], (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (results.length === 0) {
      return res.status(404).send({ message: "Username not found" });
    }

    // Check password
    const user = results[0];
    if (user.password !== password) {
      return res.status(401).send({ message: "Incorrect password" });
    }

    res.status(200).send({ message: "Login successful" });
  });
});

app.listen(3000, () => {
  console.log("Server started on port 3000");
});
